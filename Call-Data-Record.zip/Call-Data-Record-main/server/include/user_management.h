#ifndef USER_MANAGEMENT_H
#define USER_MANAGEMENT_H

#include "server.h"

void customerBilling(int client_socket);
void interoperatorBilling(int client_socket);

#endif // USER_MANAGEMENT_H
